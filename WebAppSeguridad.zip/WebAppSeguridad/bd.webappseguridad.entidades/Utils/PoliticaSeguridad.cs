﻿using System;
using System.Collections.Generic;
using System.Text;

namespace bd.webappseguridad.entidades.Utils
{
   public static class PoliticaSeguridad
    {
        public const string TienePermiso = "EstaAutorizado";
    }
}
