﻿using System;
using System.Collections.Generic;
using System.Text;

namespace bd.webappseguridad.entidades.Utils
{
   public static class WebApp
    {
        public static string BaseAddress { get; set; }
        public static string NombreAplicacion { get; set; }
        public static string BaseAddressWebAppLogin { get; set; }
    }
}
