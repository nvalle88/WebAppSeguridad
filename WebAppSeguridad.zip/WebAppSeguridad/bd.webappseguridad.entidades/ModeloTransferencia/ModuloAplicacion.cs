﻿using bd.webappseguridad.entidades.Negocio;
using System;
using System.Collections.Generic;
using System.Text;

namespace bd.webappseguridad.entidades.ModeloTransferencia
{
   public class ModuloAplicacion
    {
        public string Path { get; set; }
        public string NombreAplicacion { get; set; }

    }
}
