﻿using System;
using System.Collections.Generic;
using System.Text;

namespace bd.webappseguridad.entidades.ViewModels
{
  public  class Login
    {
        public string Usuario { get; set; }

        public string Contrasena { get; set; }

    }
}
